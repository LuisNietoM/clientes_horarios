import os
import pandas as pd
from flask import Flask, render_template, redirect, request

from sql import * 
from clientes_horarios import calculo_de_consumo_por_bloque
from demanda_horarios import calculo_de_demanda_max_por_bloque

app = Flask(__name__, template_folder='templates')

@app.route('/')
def index():
    msj = request.args.get('msj')
    esDemanda = request.args.get('esDemanda')
    return render_template('index.html', msj=msj, esDemanda=esDemanda)

@app.route('/upload')
def form_upload():
    return render_template('upload.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['archivo']
    esDemanda = request.form.get('esDemanda')
    current_directory = os.getcwd()
    url_file = os.path.join(current_directory, file.filename)
    file.save(url_file)
    return redirect(f'/?msj={url_file}&esDemanda={esDemanda}')

@app.route('/process', methods=['POST'])
def process():
    file = request.form['file']
    esDemanda = request.form.get('esDemanda')

    if esDemanda == 'on':
        df = calculo_de_demanda_max_por_bloque(file)
        pivot = df.pivot_table(
            values='DEMANDA MÁX',
            index='GRAN CLIENTE',
            columns='BLOQUE',
            aggfunc='max'
        )
        pivot.to_excel('pivot_demanda.xlsx')
        df.to_excel('result_demanda.xlsx', index=False)
        
    else:     
        df = calculo_de_consumo_por_bloque(file)
        pivot = df.pivot_table(
            values='CONSUMO',
            index='GRAN CLIENTE',
            columns='BLOQUE',
            aggfunc='sum'
        )
        pivot.to_excel('pivot_consumo.xlsx')
        df.to_excel('result_consumo.xlsx', index=False)
        guardar_registros(pivot)
        
        
        # Solo esta guardando consumo.
        # guardar_registros(pivot)
    
    table = df.to_html(classes=['table', 'table-striped'], justify='left', max_rows=20, index=False)
    return render_template('process.html',  table=table)  #

@app.route('/query', methods=['POST'])
def query():
    medidor = request.form.get('medidor')
    fecha = request.form.get('fecha')
    resultados = consultar(medidor, fecha)
    return render_template('query.html', resultados=resultados)

@app.route('/download', methods=['GET'])
def descargar_archivo():
    result = download()
    result.to_excel('Acumulado.xlsx', index=False)
    # send_from_directory(
    # directory=current_directory, 
    # path='Acumulado.xlsx', 
    # as_attachment=True)
    return redirect('/')

@app.route('/delete')
def delete():
    id = request.args.get('id')
    delete_(id)
    return redirect('/')

@app.route('/edit')
def edit():
    id = request.args.get('id')
    resultados = edit_(id)
    return render_template('edit.html', resultados=resultados)

@app.route('/acumulado')
def acumulado():
    result = download()
    return render_template('acumulado.html', acumulado=result)

@app.route('/update', methods=['POST'])
def update():
    id = request.form.get('id')
    medidor = request.form.get('medidor')
    consumo_bajo = request.form.get('consumo_bajo')
    consumo_medio = request.form.get('consumo_medio')
    consumo_punta = request.form.get('consumo_punta')
    fecha = pd.Timestamp.now().date()
    update_(medidor, consumo_bajo, consumo_medio, consumo_punta, fecha, id)
    return redirect('/')
