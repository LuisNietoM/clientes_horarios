# Librerías
import os
import pandas as pd
from flask import Flask, render_template, redirect, request, send_from_directory
from func import get_tabla_datos

app = Flask(__name__, template_folder='templates')

@app.route('/')
def index():
    msj = request.args.get('msj')
    return render_template('index.html', msj=msj)


@app.route('/upload')
def form_upload():
    return render_template('upload.html')


@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['archivo']
    current_directory = os.getcwd()
    url_file = os.path.join(current_directory, file.filename)
    file.save(url_file)
    return redirect(f'/?msj={url_file}')


@app.route('/process', methods=['POST'])
def process():
    
    # Cargar ficheros
    file = request.form['file']

    df = get_tabla_datos(file)
    pivot = df.pivot_table(index='Medidor', columns='Bloque', aggfunc={'Consumo':'sum', 'Demanda máx.':'max'})
    
    # Guardar resultados
    df.to_excel('result_boques_horarios.xlsx', index=False)
    pivot.to_excel('pivot_boques_horarios.xlsx')

    # Crear una tabla html para el preview
    table = df.to_html(
        classes=[
            'table', 
            'table-striped', 
            'table-bordered', 
            'table-hover'],
        justify='left',
        max_rows=20, index=False
    )

    return render_template('process.html', table=table)


# @app.route('/download', methods=['GET'])
# def descargar_archivo():
#     current_directory = os.getcwd()
#     return send_from_directory(directory=current_directory, path='pivot_boques_horarios.xlsx', as_attachment=True)


if __name__ == '__main__':
    app.run(debug=False)