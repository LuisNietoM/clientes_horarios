import os
import pandas as pd
from flask import Flask, render_template, redirect, request

from sql import * 
from func import get_tabla_datos

app = Flask(__name__, template_folder='templates')

@app.route('/')
def index():
    msj = request.args.get('msj')
    return render_template('index.html', msj=msj)

@app.route('/upload')
def form_upload():
    return render_template('upload.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['archivo']
    current_directory = os.getcwd()
    url_file = os.path.join(current_directory, file.filename)
    file.save(url_file)
    return redirect(f'/?msj={url_file}')

@app.route('/process', methods=['POST'])
def process():
    file = request.form['file']
    df = get_tabla_datos(file)
    pivot = df.pivot_table(
        index='Medidor', columns='Bloque', 
        aggfunc={'Consumo':'sum', 'Demanda máx.':'max'})
    df.to_excel('result_boques_horarios.xlsx', index=False)
    pivot.to_excel('pivot_boques_horarios.xlsx')
    table = df.to_html(
        classes=['table', 'table-striped', 'table-bordered', 'table-hover'],
        justify='left', max_rows=20, index=False)
    guardar_registros(pivot)
    return render_template('process.html', table=table)

@app.route('/query', methods=['POST'])
def query():
    medidor = request.form.get('medidor')
    fecha = request.form.get('fecha')
    resultados = consultar(medidor, fecha)
    return render_template('query.html', resultados=resultados)

@app.route('/download', methods=['GET'])
def descargar_archivo():
    result = download()
    result.to_excel('Acumulado.xlsx', index=False)
    # send_from_directory(
    # directory=current_directory, 
    # path='Acumulado.xlsx', 
    # as_attachment=True)
    return redirect('/')

@app.route('/delete')
def delete():
    id = request.args.get('id')
    delete_(id)
    return redirect('/')

@app.route('/edit')
def edit():
    id = request.args.get('id')
    resultados = edit_(id)
    return render_template('edit.html', resultados=resultados)

@app.route('/update', methods=['POST'])
def update():
    id = request.form.get('id')
    medidor = request.form.get('medidor')
    consumo_bajo = request.form.get('consumo_bajo')
    consumo_medio = request.form.get('consumo_medio')
    consumo_punta = request.form.get('consumo_punta')
    demanda_bajo = request.form.get('demanda_bajo')
    demanda_medio = request.form.get('demanda_medio')
    demanda_punta = request.form.get('demanda_punta')
    fecha = pd.Timestamp.now().date()
    update_(medidor, consumo_bajo, consumo_medio, consumo_punta, 
            demanda_bajo, demanda_medio, demanda_punta, fecha, id)
    return redirect('/')
