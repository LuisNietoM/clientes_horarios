import sqlite3
import pandas as pd

def guardar_registros(data):
    conexion = sqlite3.connect("db.db")
    data['Fecha'] = pd.Timestamp.now().date()

    conexion.execute('''
        CREATE TABLE IF NOT EXISTS consumo_horario (
            "id" INTEGER PRIMARY KEY AUTOINCREMENT,
            "GRAN CLIENTE" TEXT,
            "Bajo" REAL,
            "Medio" REAL,
            "Punta" REAL,
            "Fecha" DATE,
            "UpdateAt" DATE
        )''')

    data.to_sql('consumo_horario', conexion, if_exists='append') 
    conexion.close()


def consultar(medidor=None, fecha=None):
    conn = sqlite3.connect('db.db')
    cursor = conn.cursor()

    if medidor and fecha:
        query = "SELECT * FROM consumo_horario WHERE `GRAN CLIENTE`=? AND Fecha = ?;"
        parameters = (medidor, fecha)
    elif medidor:
        query = "SELECT * FROM consumo_horario WHERE `GRAN CLIENTE`=?"
        parameters = (medidor,)
    elif fecha:
        query = "SELECT * FROM consumo_horario WHERE Fecha = ?;"
        parameters = (fecha,)
    else:
        query = "SELECT * FROM consumo_horario"
        parameters = ()
    cursor.execute(query, parameters)
    resultados = cursor.fetchall()
    conn.close()
    return resultados


def download():
    conexion = sqlite3.connect("db.db")

    sql = '''
    SELECT 
        `GRAN CLIENTE`,
        SUM(Bajo) as TotalBajo,
        SUM(Medio) as TotalMedio,
        SUM(Punta) as TotalPunta
    FROM consumo_horario
    GROUP BY `GRAN CLIENTE`;
    '''
    result = pd.read_sql(sql, conexion)
    conexion.close()
    return result


def delete_(id):
    sql = "DELETE FROM consumo_horario WHERE id=?"
    conexion = sqlite3.connect("db.db")
    conexion.execute(sql, (id,))
    conexion.commit()
    conexion.close()

def edit_(id):
    sql = "SELECT * FROM consumo_horario WHERE id=?"
    conn = sqlite3.connect('db.db')
    cursor = conn.cursor()
    cursor.execute(sql, (id,))
    resultados = cursor.fetchall()
    conn.close()
    return resultados

def update_(medidor, consumo_bajo, consumo_medio, consumo_punta, fecha, id):

    sql = "UPDATE consumo_horario SET `GRAN CLIENTE`=?, Bajo=?, Medio=?, Punta=?, UpdateAt=? WHERE id=?"
    conn = sqlite3.connect('db.db')
    cursor = conn.cursor()
    cursor.execute(sql, (medidor, consumo_bajo, consumo_medio, consumo_punta, fecha, id))
    conn.commit()
    conn.close()