import sqlite3
import pandas as pd

def guardar_registros(data):
    conexion = sqlite3.connect("db.db")
    data['Fecha'] = pd.Timestamp.now().date()

    conexion.execute('''
        CREATE TABLE IF NOT EXISTS consumo_horario (
            "id" INTEGER PRIMARY KEY AUTOINCREMENT,
            "Medidor" INTEGER,
            "('Consumo', 'Bajo')" REAL,
            "('Consumo', 'Medio')" REAL,
            "('Consumo', 'Punta')" REAL,
            "('Demanda máx.', 'Bajo')" REAL,
            "('Demanda máx.', 'Medio')" REAL,
            "('Demanda máx.', 'Punta')" REAL,
            "('Fecha', '')" DATE,
            "('Update', '')" DATE
        )
    ''')
    data.to_sql('consumo_horario', conexion, if_exists='append') 
    conexion.close()


def consultar(medidor=None, fecha=None):
    conn = sqlite3.connect('db.db')
    cursor = conn.cursor()

    if medidor and fecha:
        query = "SELECT * FROM consumo_horario WHERE Medidor=? AND `('Fecha', '')` = ?;"
        parameters = (medidor, fecha)
    elif medidor:
        query = "SELECT * FROM consumo_horario WHERE Medidor=?"
        parameters = (medidor,)
    elif fecha:
        query = "SELECT * FROM consumo_horario WHERE `('Fecha', '')` = ?;"
        parameters = (fecha,)
    else:
        query = "SELECT * FROM consumo_horario"
        parameters = ()
    cursor.execute(query, parameters)
    resultados = cursor.fetchall()
    conn.close()
    return resultados


def download():
    conexion = sqlite3.connect("db.db")

    sql = '''
    SELECT 
        "Medidor",
        SUM("('Consumo', 'Bajo')") as Total_Consumo_Bajo,
        SUM("('Consumo', 'Medio')") as Total_Consumo_Medio,
        SUM("('Consumo', 'Punta')") as Total_Consumo_Punta,
        SUM("('Demanda máx.', 'Bajo')") as Total_Demanda_Bajo,
        SUM("('Demanda máx.', 'Medio')") as Total_Demanda_Medio,
        SUM("('Demanda máx.', 'Punta')") as Total_Demanda_Punta
    FROM consumo_horario
    GROUP BY "Medidor";
    '''
    result = pd.read_sql(sql, conexion)
    conexion.close()
    return result


def delete_(id):
    sql = "DELETE FROM consumo_horario WHERE id=?"
    conexion = sqlite3.connect("db.db")
    conexion.execute(sql, (id,))
    conexion.commit()
    conexion.close()

def edit_(id):
    sql = "SELECT * FROM consumo_horario WHERE id=?"
    conn = sqlite3.connect('db.db')
    cursor = conn.cursor()
    cursor.execute(sql, (id,))
    resultados = cursor.fetchall()
    conn.close()
    return resultados

def update_(medidor, 
            consumo_bajo, 
            consumo_medio, 
            consumo_punta, 
            demanda_bajo, 
            demanda_medio, 
            demanda_punta, 
            fecha, 
            id):

    sql = "UPDATE consumo_horario SET Medidor=?, `('Consumo', 'Bajo')`=?, `('Consumo', 'Medio')`=?, `('Consumo', 'Punta')`=?, `('Demanda máx.', 'Bajo')`=?, `('Demanda máx.', 'Medio')`=?, `('Demanda máx.', 'Punta')`=?, `('Update', '')`=? WHERE id=?"
    conn = sqlite3.connect('db.db')
    cursor = conn.cursor()
    cursor.execute(sql, (medidor, consumo_bajo, consumo_medio, consumo_punta, demanda_bajo, demanda_medio, demanda_punta, fecha, id))
    conn.commit()
    conn.close()