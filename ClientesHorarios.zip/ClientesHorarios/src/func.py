import pandas as pd
from dias_feriados import dias_feriados

def get_tabla_datos(file):
    df = pd.read_csv(file, decimal='.', thousands=',', parse_dates=['FECHAFULL'])
    df['WEEKDAY'] = df['FECHAFULL'].dt.day_name()

    medidor_     = []
    dia_         = []
    horario_     = []
    consumo_     = []
    bloque_      = []
    demanda_max_ = []

    medidores = df['SERIALNO'].unique()
    dias      = df['FECHAFULL'].dt.date.unique()
    un_dia    = pd.DateOffset(days=1)

    for medidor in medidores:
        for dia in dias:
            x = df[(df['SERIALNO'] == medidor) & (df['FECHAFULL'].dt.date == dia)].copy()

            if x['WEEKDAY'].unique() == 'Sunday' or (pd.to_datetime(dia) in dias_feriados):

                inicio = pd.to_datetime(dia) # Inicio del domingo
                fin = (inicio + un_dia) # Fin del domingo
                
                y = df[(df['SERIALNO'] == medidor) & (df['FECHAFULL'] >= inicio) & (df['FECHAFULL'] <= fin)].copy()

                medidor_.append(medidor)
                dia_.append(dia)
                horario_.append('De ' + str(inicio.time()) + ' a ' + str(fin.time()))
                consumo_.append(y['KWHDEL_ACUM'].max() - y['KWHDEL_ACUM'].min())
                demanda_max_.append(y['KWDEL'].max())
                bloque_.append('Bajo')

            elif x['WEEKDAY'].unique() == 'Saturday':
                
                # El sábado tiene 3 bloques. 
                # Bloque 1
                inicio1 = pd.to_datetime(dia) # 00:00
                fin1 = pd.to_datetime(dia) + pd.DateOffset(hours=11)# 11:00

                y1 = df[(df['SERIALNO'] == medidor) & (df['FECHAFULL'] >= inicio1) & (df['FECHAFULL'] <= fin1)].copy()

                medidor_.append(medidor)
                dia_.append(dia)
                horario_.append('De ' + str(inicio1.time()) + ' a ' + str(fin1.time()))
                consumo_.append(y1['KWHDEL_ACUM'].max() - y1['KWHDEL_ACUM'].min())
                demanda_max_.append(y1['KWDEL'].max())
                bloque_.append('Bajo')

                # Bloque 2
                inicio2 = fin1 # 11:00
                fin2 = pd.to_datetime(dia) + pd.DateOffset(hours=23)# 23:00

                y2 = df[(df['SERIALNO'] == medidor) & (df['FECHAFULL'] >= inicio2) & (df['FECHAFULL'] <= fin2)].copy()
                
                medidor_.append(medidor)
                dia_.append(dia)
                horario_.append('De ' + str(inicio2.time()) + ' a ' + str(fin2.time()))
                consumo_.append(y2['KWHDEL_ACUM'].max() - y2['KWHDEL_ACUM'].min())
                demanda_max_.append(y2['KWDEL'].max())
                bloque_.append('Medio')

                # Bloque 3
                inicio3 = fin2 # 23:00
                fin3 = (inicio1 + un_dia)  # 00:00 del día siguiente

                y3 = df[(df['SERIALNO'] == medidor) & (df['FECHAFULL'] >= inicio3) & (df['FECHAFULL'] <= fin3)].copy()

                medidor_.append(medidor)
                dia_.append(dia)
                horario_.append('De ' + str(inicio3.time()) + ' a ' + str(fin3.time()))
                consumo_.append(y3['KWHDEL_ACUM'].max() - y3['KWHDEL_ACUM'].min())
                demanda_max_.append(y3['KWDEL'].max())
                bloque_.append('Bajo')

            else: 

                # De lunes a viernes también hay tres bloques. 
                # Bloque 1
                inicio1 = pd.to_datetime(dia) # 00:00
                fin1 = pd.to_datetime(dia) + pd.DateOffset(hours=9)# 09:00

                y1 = df[(df['SERIALNO'] == medidor) & (df['FECHAFULL'] >= inicio1) & (df['FECHAFULL'] <= fin1)].copy()

                medidor_.append(medidor)
                dia_.append(dia)
                horario_.append('De ' + str(inicio1.time()) + ' a ' + str(fin1.time()))
                consumo_.append(y1['KWHDEL_ACUM'].max() - y1['KWHDEL_ACUM'].min())
                demanda_max_.append(y1['KWDEL'].max())
                bloque_.append('Bajo')

                # Bloque 2
                inicio2 = fin1 # 09:00
                fin2 = pd.to_datetime(dia) + pd.DateOffset(hours=17)# 17:00

                y2 = df[(df['SERIALNO'] == medidor) & (df['FECHAFULL'] >= inicio2) & (df['FECHAFULL'] <= fin2)].copy()
                
                medidor_.append(medidor)
                dia_.append(dia)
                horario_.append('De ' + str(inicio2.time()) + ' a ' + str(fin2.time()))
                consumo_.append(y2['KWHDEL_ACUM'].max() - y2['KWHDEL_ACUM'].min())
                demanda_max_.append(y2['KWDEL'].max())
                bloque_.append('Punta')

                # Bloque 3
                inicio3 = fin2 # 17:00
                fin3 = (inicio1 + un_dia)  # 00:00 del día siguiente

                y3 = df[(df['SERIALNO'] == medidor) & (df['FECHAFULL'] >= inicio3) & (df['FECHAFULL'] <= fin3)].copy()

                medidor_.append(medidor)
                dia_.append(dia)
                horario_.append('De ' + str(inicio3.time()) + ' a ' + str(fin3.time()))
                consumo_.append(y3['KWHDEL_ACUM'].max() - y3['KWHDEL_ACUM'].min())
                demanda_max_.append(y3['KWDEL'].max())
                bloque_.append('Medio')            
                

    tabla_de_datos = pd.DataFrame({
        'Medidor': medidor_ ,
        'Fecha': dia_,
        'Horario': horario_,
        'Consumo': consumo_,
        'Bloque': bloque_,
        'Demanda máx.': demanda_max_
    })

    return tabla_de_datos

