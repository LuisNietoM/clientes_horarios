import pandas as pd

# Lista de días feriados en Panamá para el año 2023
dias_feriados = [
    pd.to_datetime('2023-01-01'),  # Año Nuevo
    pd.to_datetime('2023-01-09'),  # Día de los Mártires
    pd.to_datetime('2023-02-24'),  # Día de la Bandera
    pd.to_datetime('2023-03-01'),  # Día de la Independencia
    pd.to_datetime('2023-04-6'),   # Jueves Santo
    pd.to_datetime('2023-04-7'),   # Viernes Santo
    pd.to_datetime('2023-05-1'),   # Día del Trabajo
    pd.to_datetime('2023-11-3'),   # Separación de Panamá de Colombia
    pd.to_datetime('2023-11-4'),   # Día de los Símbolos de la Nación
    pd.to_datetime('2023-11-5'),   # Primer Grito de Independencia
    pd.to_datetime('2023-11-10'),  # Día de la Independencia de Panamá de España
    pd.to_datetime('2023-12-2'),   # Día de la Madre
    pd.to_datetime('2023-12-8'),   # Día de la Madre
    pd.to_datetime('2023-12-25'),  # Navidad
]