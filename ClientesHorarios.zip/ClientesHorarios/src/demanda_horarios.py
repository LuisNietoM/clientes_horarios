
import numpy as np
import pandas as pd
from dias_feriados import dias_feriados


def calculo_de_demanda_max_por_bloque(archivo):

    df = pd.read_csv(archivo, header=None)
    columns = ["FECHA", "HORA", "X", "GRAN CLIENTE", "MEDICIONES"]
    df.columns = columns
    df['FECHA'] = pd.to_datetime(df['FECHA'], format="%m/%d/%Y")

    clientes = df['GRAN CLIENTE'].unique()
    fechas = df['FECHA'].unique()

    cliente_    = []
    fecha_      = []
    horario_    = []
    bloque_     = []
    demanda_    = []

    for cliente in clientes:
        x = df[df['GRAN CLIENTE'] == cliente].copy()

        for fecha in fechas:
            y = x[x['FECHA'] == fecha].copy()

            # Aquí empiezan las validaciones
            if fecha in dias_feriados or pd.to_datetime(fecha).day_name() == 'Sunday':
                z = y.loc[(y['HORA'] <= 2400), 'MEDICIONES'].copy()

                cliente_.append(cliente)
                fecha_.append(fecha)
                horario_.append('De 00:00 a 24:00')
                bloque_.append('Bajo')
                demanda_.append(np.max(z))

            elif pd.to_datetime(fecha).day_name() == 'Saturday':
                z1 = y.loc[(y['HORA'] <= 1100), 'MEDICIONES'].copy()
                cliente_.append(cliente)
                fecha_.append(fecha)
                horario_.append('De 00:00 a 11:00')
                bloque_.append('Bajo')
                demanda_.append(np.max(z1))

                z2 = y.loc[(y['HORA'] > 1100) & (y['HORA'] <= 2300), 'MEDICIONES'].copy()
                cliente_.append(cliente)
                fecha_.append(fecha)
                horario_.append('De 11:00 a 23:00')
                bloque_.append('Medio')
                demanda_.append(np.max(z2))

                z3 = y.loc[(y['HORA'] > 2300), 'MEDICIONES'].copy()
                cliente_.append(cliente)
                fecha_.append(fecha)
                horario_.append('De 23:00 a 24:00')
                bloque_.append('Bajo')
                demanda_.append(np.max(z3))

            else:
                z1 = y.loc[(y['HORA'] <= 900), 'MEDICIONES'].copy()
                cliente_.append(cliente)
                fecha_.append(fecha)
                horario_.append('De 00:00 a 09:00')
                bloque_.append('Bajo')
                demanda_.append(np.max(z1))

                z2 = y.loc[(y['HORA'] > 900) & (y['HORA'] <= 1700), 'MEDICIONES'].copy()
                cliente_.append(cliente)
                fecha_.append(fecha)
                horario_.append('De 09:00 a 17:00')
                bloque_.append('Punta')
                demanda_.append(np.max(z2))

                z3 = y.loc[(y['HORA'] > 1700), 'MEDICIONES'].copy()
                cliente_.append(cliente)
                fecha_.append(fecha)
                horario_.append('De 17:00 a 24:00')
                bloque_.append('Medio')
                demanda_.append(np.max(z3))

    result = pd.DataFrame({
        'GRAN CLIENTE'  : cliente_,
        'FECHA'         : fecha_,
        'HORARIO'       : horario_,
        'DEMANDA MÁX'   : demanda_,
        'BLOQUE'        : bloque_
    })

    return result