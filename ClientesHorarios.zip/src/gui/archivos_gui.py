import tkinter as tk
from tkinter import ttk, filedialog
from threading import Thread
from logica_negocio.demanda_logica import DemandaMaxPorBloqueLogica
from logica_negocio.consumo_logica import ConsumoPorBloqueLogica
from logica_negocio.master_logica import MasterLogica
from logica_negocio.argos_edemet_logica import ArgosEdemetLogica

class CargarArchivosDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Formulario - Cargar archivos")
        self.geometry("687x350")
        self.resizable(False, False)
        self.iconbitmap("./logo.ico")

        self.demanda_logica = DemandaMaxPorBloqueLogica()
        self.consumo_logica = ConsumoPorBloqueLogica()
        self.argos_edemet_logica = ArgosEdemetLogica()
        self.master_logica = MasterLogica()

        ttk.Label(self, text="Buscar archivo").grid(row=0, column=0, padx=10, pady=5,)
        ttk.Label(self, text="Ruta del archivo").grid(row=0, column=1, padx=10, pady=5)

        self.btn_demanda = ttk.Button(self, text="Demanda .csv", command=self.cargar_demanda)
        self.btn_demanda.grid(row=1, column=0, padx=10, pady=5, sticky="ew")
        
        self.lbl_demanda = ttk.Label(self, text="No ha seleccionado ningun archivo")
        self.lbl_demanda.grid(row=1, column=1, padx=10, pady=5)
        
        self.btn_consumo = ttk.Button(self, text="Consumos .xlsx", command=self.cargar_consumo)
        self.btn_consumo.grid(row=2, column=0, padx=10, pady=5, sticky="ew")
        
        self.lbl_consumo = ttk.Label(self, text="No ha seleccionado ningun archivo")
        self.lbl_consumo.grid(row=2, column=1, padx=10, pady=5)
        
        self.btn_edemet = ttk.Button(self, text="Edemet .xlsx", command=self.cargar_edemet)
        self.btn_edemet.grid(row=3, column=0, padx=10, pady=5, sticky="ew")
        
        self.lbl_edemet = ttk.Label(self, text="No ha seleccionado ningun archivo")
        self.lbl_edemet.grid(row=3, column=1, padx=10, pady=5)
        
        self.btn_reactiva = ttk.Button(self, text="Energía reactiva .xlsx", command=self.cargar_reactiva)
        self.btn_reactiva.grid(row=4, column=0, padx=10, pady=5, sticky="ew")
        
        self.lbl_reactiva = ttk.Label(self, text="No ha seleccionado ningun archivo")
        self.lbl_reactiva.grid(row=4, column=1, padx=10, pady=5)
        
        self.btn_argos = ttk.Button(self, text="Argos .xlsx", command=self.cargar_argos)
        self.btn_argos.grid(row=5, column=0, padx=10, pady=5, sticky="ew")
        
        self.lbl_argos = ttk.Label(self, text="No ha seleccionado ningun archivo")
        self.lbl_argos.grid(row=5, column=1, padx=10, pady=5)
        
        self.columnconfigure(1, weight=1)

        btn_cargar_archivos = ttk.Button(self, text="Guardar", command=self._run, style="success.TButton")
        btn_cargar_archivos.grid(row=6, columnspan=2, sticky="n", pady=20)

        self.progressbar = ttk.Progressbar(self, mode="indeterminate")
        self.progressbar.grid(row=7, columnspan=2, sticky="ew", padx=30, pady=10)
    
    def _run(self,):
        self.progressbar.start()
        # self.cargar_archivos()
        t = Thread(target=self.cargar_archivos)
        t.start()

    def cargar_archivos(self):
        # Obtener las rutas de los archivos
        archivo_demanda = self.lbl_demanda.cget("text")
        archivo_consumo = self.lbl_consumo.cget("text")
        archivo_edemet = self.lbl_edemet.cget("text")
        archivo_reactiva = self.lbl_reactiva.cget("text")
        archivo_argos = self.lbl_argos.cget("text")
        
        # Llamar a los métodos de procesamiento
        if archivo_demanda and archivo_demanda != "No ha seleccionado ningun archivo":
            self.procesar_archivo_demanda(archivo_demanda)
        if archivo_consumo and archivo_consumo != "No ha seleccionado ningun archivo":
            self.procesar_archivo_consumo(archivo_consumo)
        if archivo_edemet and archivo_edemet != "No ha seleccionado ningun archivo":
            self.procesar_archivo_edemet(archivo_edemet)
        if archivo_reactiva and archivo_reactiva != "No ha seleccionado ningun archivo":
            self.procesar_archivo_reactiva(archivo_reactiva)
        if archivo_argos and archivo_argos != "No ha seleccionado ningun archivo":
            self.procesar_archivo_argos(archivo_argos)

        self.destroy()

    def cargar_demanda(self):
        archivo = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if archivo:
            self.lbl_demanda.config(text=archivo)
        else:
            self.lbl_demanda.config(text="No ha seleccionado ningun archivo")

    def cargar_consumo(self):
        archivo = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
        if archivo:
            self.lbl_consumo.config(text=archivo)
        else:
            self.lbl_consumo.config(text="No ha seleccionado ningun archivo")

    def cargar_edemet(self):
        archivo = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
        if archivo:
            self.lbl_edemet.config(text=archivo)
        else:
            self.lbl_edemet.config(text="No ha seleccionado ningun archivo")

    def cargar_reactiva(self):
        archivo = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
        if archivo:
            self.lbl_reactiva.config(text=archivo)
        else:
            self.lbl_reactiva.config(text="No ha seleccionado ningun archivo")

    def cargar_argos(self):
        archivo = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
        if archivo:
            self.lbl_argos.config(text=archivo)
        else:
            self.lbl_argos.config(text="No ha seleccionado ningun archivo")


    def procesar_archivo_demanda(self, archivo):
        try:
            self.demanda_logica.calcular(archivo)
            print("Éxito", "Los datos fueron cargados exitosamente.")
        except Exception as e: 
            print("Error", f"Ocurrió un error al procesar el archivo: {e}")

    def procesar_archivo_consumo(self, archivo):
        try: 
            self.consumo_logica.calcular(archivo)
            print("Éxito", "Los datos fueron cargados exitosamente.")
        except Exception as e: 
            print("Error", f"Ocurrió un error al procesar el archivo: {e}") 

    def procesar_archivo_edemet(self, archivo):
        try: 
            self.argos_edemet_logica.set_edemet(archivo)
            print("Éxito", "Los datos fueron cargados exitosamente.")
        except Exception as e: 
            print("Error", f"Ocurrió un error al procesar el archivo: {e}")

    def procesar_archivo_reactiva(self, archivo):
        try: 
            self.master_logica.consumo_reactivo(archivo)
            print("Éxito", "Los datos fueron cargados exitosamente.")
        except Exception as e: 
            print("Error", f"Ocurrió un error al procesar el archivo: {e}")

    def procesar_archivo_argos(self, archivo):
        try: 
            self.argos_edemet_logica.set_argos(archivo)
            print("Éxito", "Los datos fueron cargados exitosamente.")
        except Exception as e: 
            print("Error", f"Ocurrió un error al procesar el archivo: {e}")
