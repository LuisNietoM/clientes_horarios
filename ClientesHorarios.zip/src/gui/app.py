import pandas as pd
import tkinter as tk
from tkinter import Menu, messagebox, filedialog
from gui.cliente_gui import ClienteDialog
from gui.archivos_gui import CargarArchivosDialog
from gui.feriado_gui import DiasFestivosDialog
from gui.master_gui import ConsultaDatosDialog
from logica_negocio.cliente_logica import ClienteLogica
from logica_negocio.consumo_logica import ConsumoPorBloqueLogica
from logica_negocio.demanda_logica import DemandaMaxPorBloqueLogica
from ttkbootstrap import Style

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("APP GRANDES CLIENTES")
        self.iconbitmap("./logo.ico")
        self.state('zoomed')
        self.style = Style()
        self = self.style.master
        
        menubar = Menu(self)
        cliente_menu = Menu(menubar, tearoff=0)
        cliente_menu.add_command(label="Formulario de cliente", command=self.abrir_formulario_cliente)
        cliente_menu.add_command(label="Carga masiva de clientes", command=self.carga_masiva)
        cliente_menu.add_separator()
        cliente_menu.add_command(label="Descargar plantillla", command=self.descarga_plantilla)
        menubar.add_cascade(label="Cliente", menu=cliente_menu)

        archivos_menu = Menu(menubar, tearoff=0)
        archivos_menu.add_command(label="Cargar archivos", command=self.open_cargar_archivos_dialog)
        archivos_menu.add_command(label="Fiesta o duelo nacional",  command=self.open_dias_feriados_dialog)
        archivos_menu.add_separator()
        archivos_menu.add_command(label="Descargar resultados", command=self.open_consulta_datos_dialog)
        menubar.add_cascade(label="Datos", menu=archivos_menu)

        detalle_menu = Menu(menubar, tearoff=0)
        detalle_menu.add_command(label="Franjas consumos", command=self.get_detalle_consumo)
        detalle_menu.add_command(label="Franjas demandas",  command=self.get_detalle_demanda)
        menubar.add_cascade(label="Detalle", menu=detalle_menu)

        self.config(menu=menubar)

    def abrir_formulario_cliente(self):
        form = ClienteDialog(self)
        self.wait_window(form)

    def open_cargar_archivos_dialog(self):
        dialog = CargarArchivosDialog(self)
        self.wait_window(dialog)

    def open_dias_feriados_dialog(self):
        dialog = DiasFestivosDialog(self)
        self.wait_window(dialog)

    def open_consulta_datos_dialog(self):
        dialog = ConsultaDatosDialog(self)
        self.wait_window(dialog)

    def descarga_plantilla(self):
        logica = ClienteLogica()
        try:
            logica.listar()
            messagebox.showinfo("ENSA - Grandes Clientes", "Plantilla descargada")
        except Exception as e:
            messagebox.showerror("ENSA - Grandes Clientes", f"Ocurrio un error {e}")

    def carga_masiva(self):
        archivo = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
        try:
            df = pd.read_excel(archivo)
            logica = ClienteLogica()
            logica.cargar_datos(df)
            messagebox.showinfo("ENSA - Grandes Clientes", "Datos cargados exitosamente")
        except Exception as e:
            messagebox.showerror("ENSA - Grandes Clientes", f"Ocurrio un error {e}")

    def get_detalle_consumo(self):
        try:
            logica = ConsumoPorBloqueLogica()
            df = logica.detalles()
            df.to_excel("detalle_franjas_consumos.xlsx", index=False)
            messagebox.showinfo("ENSA - Grandes Clientes", "Datos descargados exitosamente")
        except Exception as e:
            messagebox.showerror("ENSA - Grandes Clientes", f"Ocurrio un error {e}")

    def get_detalle_demanda(self):
        try:
            logica = DemandaMaxPorBloqueLogica()
            df = logica.detalles()
            df.to_excel("detalle_franjas_demanda_max.xlsx", index=False)
            messagebox.showinfo("ENSA - Grandes Clientes", "Datos descargados exitosamente")
        except Exception as e:
            messagebox.showerror("ENSA - Grandes Clientes", f"Ocurrio un error {e}")



            





