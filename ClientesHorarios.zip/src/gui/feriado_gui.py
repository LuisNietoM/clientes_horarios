import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
from logica_negocio.feriado_logica import DiaFeriadoLogica

class DiasFestivosDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Formulario - Días Festivos")
        self.geometry("650x350")
        self.resizable(False, False)
        self.iconbitmap("./logo.ico")
        self.logica = DiaFeriadoLogica()

        ttk.Label(self, text="Fecha:").grid(row=0, column=0, sticky="w", padx=10)
        ttk.Label(self, text="Descripción:").grid(row=0, column=1, sticky="w")

        self.dte_fecha = DateEntry(self)
        self.dte_fecha.grid(row=1, column=0, padx=10, pady=5)

        self.txt_descrip = ttk.Entry(self, width=70)
        self.txt_descrip.grid(row=1, column=1, pady=5)

        self.btn_add = ttk.Button(self, text="Agregar", style="success.TButton", command=self.agregar)
        self.btn_add.grid(row=1, column=2, padx=10, pady=5)

        self.frame = ttk.Frame(self)
        self.frame.grid(row=2, columnspan=3, padx=5, sticky="nsew")
        self.frame.grid_columnconfigure(0, weight=1)
        self.frame.grid_columnconfigure(1, weight=0)

        self.tree = ttk.Treeview(self.frame, columns=[f"col{i+1}" for i in range(2)], show='headings')
        self.tree.grid(row=0, column=0, sticky="nsew")
        
        self.scroll_y = ttk.Scrollbar(self.frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.scroll_y.grid(row=0, column=1, sticky="ns", padx=5)
        self.tree.configure(yscrollcommand=self.scroll_y.set)
        
        cols = ("Fecha", "Descripción")
        for i in range(2):
            col = f"col{i+1}"
            self.tree.heading(col, text=f"{cols[i]}")
            self.tree.column(col, anchor="center") 

        self.btn_eliminar = ttk.Button(self, text="Eliminar", style="danger.TButton", command=self.eliminar)
        self.btn_eliminar.grid(row=3, columnspan=3, sticky="n", pady=10)
    
        self.consultar()

    def agregar(self):
        fecha = self.dte_fecha.get_date()
        descrip = self.txt_descrip.get()
        try: 
            self.logica.agregar(fecha, descrip)
            self.txt_descrip.delete(0, tk.END)
            self.consultar()
            messagebox.showinfo("ENSA - Grandes Clientes", "Fecha registrada exitosamente")
        except Exception as e:
            messagebox.showerror("ENSA - Grandes Clientes", f"Ocurrio un error {e}")

    def consultar(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        try:
            datos = self.logica.consultar()
            for dato in datos:
                self.tree.insert("", tk.END, values=dato)
        except Exception as e:
            messagebox.showerror("ENSA - Grandes Clientes", f"Ocurrio un error {e}")

    def eliminar(self):
        try:
            id = self.tree.selection() # Id del treeview
            fecha= self.tree.item(id, 'values')[0] # Primer valor de la tupla
            self.logica.eliminar(fecha)
            self.consultar()
            messagebox.showinfo("ENSA - Grandes Clientes", "Fecha eliminada exitosamente")
        except Exception as e:
            messagebox.showerror("ENSA - Grandes Clientes", f"Ocurrio un error {e}")


        
