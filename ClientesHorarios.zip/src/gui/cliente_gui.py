import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
from logica_negocio.cliente_logica import ClienteLogica

class ClienteDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Formulario - Cliente")
        self.geometry("485x450")
        self.resizable(False, False)
        self.iconbitmap("./logo.ico")
        self.logica = ClienteLogica()

        # Configure the grid
        self.grid_columnconfigure(1, weight=1)

        ttk.Label(self, text="NAC:").grid(row=0, column=0, padx=10, pady=5, sticky="w")
        self.txt_nac = ttk.Entry(self, width=50)
        self.txt_nac.grid(row=0, column=1, padx=10, pady=5)
        self.txt_nac.bind("<Return>", self.buscar_cliente)

        ttk.Label(self, text="Nickname consumo:").grid(row=1, column=0, padx=10, pady=5, sticky="w")
        self.txt_nickname_consumo = ttk.Entry(self, width=50)
        self.txt_nickname_consumo.grid(row=1, column=1, padx=10, pady=5)

        ttk.Label(self, text="Nickname demanda:").grid(row=2, column=0, padx=10, pady=5, sticky="w")
        self.txt_nickname_demanda = ttk.Entry(self, width=50)
        self.txt_nickname_demanda.grid(row=2, column=1, padx=10, pady=5)

        ttk.Label(self, text="Instalación:").grid(row=3, column=0, padx=10, pady=5, sticky="w")
        self.txt_instalacion = ttk.Entry(self, width=50)
        self.txt_instalacion.grid(row=3, column=1, padx=10, pady=5)

        ttk.Label(self, text="Medidor:").grid(row=4, column=0, padx=10, pady=5, sticky="w")
        self.txt_medidor = ttk.Entry(self, width=50)
        self.txt_medidor.grid(row=4, column=1, padx=10, pady=5)

        ttk.Label(self, text="CTE:").grid(row=5, column=0, padx=10, pady=5, sticky="w")
        self.txt_cte = ttk.Entry(self, width=50)
        self.txt_cte.grid(row=5, column=1, padx=10, pady=5)

        ttk.Label(self, text="Nombre:").grid(row=6, column=0, padx=10, pady=5, sticky="w")
        self.txt_nombre = ttk.Entry(self, width=50)
        self.txt_nombre.grid(row=6, column=1, padx=10, pady=5)

        ttk.Label(self, text="Tarifa:").grid(row=7, column=0, padx=10, pady=5, sticky="w")
        self.cmb_tarifa = ttk.Combobox(self, width=47)
        self.cmb_tarifa.grid(row=7, column=1, padx=10, pady=5)
        self.cmb_tarifa["values"] = ['---Seleccione el tipo de tarifa', 'ATD', 'ATH', 'BTD', 'BTH', 'MTD', 'MTH']
        self.cmb_tarifa.current(0)

        ttk.Label(self, text="Fecha de entrada:").grid(row=8, column=0, padx=10, pady=5, sticky="w")
        self.dte_fecha_entrada = DateEntry(self, width=47)
        self.dte_fecha_entrada.grid(row=8, column=1, padx=10, pady=5)
        
        ttk.Label(self, text="Precio CPG:").grid(row=9, column=0, padx=10, pady=5, sticky="w")
        self.txt_precio_cpg = ttk.Entry(self, width=50)
        self.txt_precio_cpg.grid(row=9, column=1, padx=10, pady=5)

        self.frame_btn = ttk.Frame(self)
        self.frame_btn.grid(row=10, column=1, padx=10, pady=10, sticky="ew") 
        self.frame_btn.columnconfigure(0, weight=1)

        self.btn_guardar = ttk.Button(self.frame_btn, text="Guardar", style="success.TButton", command=self.crear_cliente)
        self.btn_guardar.grid(row=0, column=0, padx=10, pady=5, sticky="e")

        self.btn_editar = ttk.Button(self.frame_btn, text="Editar", style="warning.TButton", command=self.editar_cliente)
        self.btn_editar.grid(row=0, column=1, padx=10, pady=5, sticky="e")

        self.btn_eliminar = ttk.Button(self.frame_btn, text="Eliminar", style="danger.TButton", command=self.eliminar_cliente)
        self.btn_eliminar.grid(row=0, column=2, padx=10, pady=5, sticky="e")

    def crear_cliente(self):
        nac = self.txt_nac.get()
        nickname_consumo = self.txt_nickname_consumo.get()
        nickname_demanda = self.txt_nickname_demanda.get()
        instalacion = self.txt_instalacion.get()
        medidor = self.txt_medidor.get()
        cte = self.txt_cte.get()
        nombre = self.txt_nombre.get()
        tarifa = self.cmb_tarifa.get()
        fecha_entrada = self.dte_fecha_entrada.get_date()
        precio_cpg = self.txt_precio_cpg.get()

        try:
            self.logica.crear_cliente(
                nac,
                nickname_consumo,
                nickname_demanda,
                instalacion,
                medidor,
                cte,
                nombre,
                tarifa,
                fecha_entrada,
                precio_cpg,
            )
            self.destroy()
            messagebox.showinfo("ENSA - Grandes Clientes", "Cliente registrado exitosamente")
        except Exception as e:
            messagebox.showerror("ENSA - Grandes Clientes", f"Ocurrio un error {e}")
            

    def buscar_cliente(self, event):
        nac = self.txt_nac.get()
        try:
            res = self.logica.buscar_cliente(nac)
            if not res:
                messagebox.showinfo("ENSA - Grandes Clientes", "No se encontró este NAC")
                self.limpiar_campos()
            else:
                self.txt_nickname_consumo.delete(0, tk.END)
                self.txt_nickname_consumo.insert(0, res[0][2])

                self.txt_nickname_demanda.delete(0, tk.END)
                self.txt_nickname_demanda.insert(0, res[0][3])

                self.txt_instalacion.delete(0, tk.END)
                self.txt_instalacion.insert(0, res[0][4])

                self.txt_medidor.delete(0, tk.END)
                self.txt_medidor.insert(0, res[0][5])

                self.txt_cte.delete(0, tk.END)
                self.txt_cte.insert(0, res[0][6])

                self.txt_nombre.delete(0, tk.END)
                self.txt_nombre.insert(0, res[0][7])

                self.cmb_tarifa.set(res[0][8])

                self.dte_fecha_entrada.delete(0, tk.END)
                self.dte_fecha_entrada.insert(0, res[0][9])

                self.txt_precio_cpg.delete(0, tk.END)
                self.txt_precio_cpg.insert(0, res[0][10])

        except Exception as e:
            messagebox.showerror("ENSA - Grandes Clientes", f"Ocurrió un error: {e}")

    def editar_cliente(self):
        nac = self.txt_nac.get()
        nickname_consumo = self.txt_nickname_consumo.get()
        nickname_demanda = self.txt_nickname_demanda.get()
        instalacion = self.txt_instalacion.get()
        medidor = self.txt_medidor.get()
        cte = self.txt_cte.get()
        nombre = self.txt_nombre.get()
        tarifa = self.cmb_tarifa.get()
        fecha_entrada = self.dte_fecha_entrada.get_date()
        precio_cpg = self.txt_precio_cpg.get()

        try:
            self.logica.editar_cliente(
                nac,
                nickname_consumo,
                nickname_demanda,
                instalacion,
                medidor,
                cte,
                nombre,
                tarifa,
                fecha_entrada,
                precio_cpg,
            )
            self.destroy()
            messagebox.showinfo("ENSA - Grandes Clientes", "Cliente editado exitosamente")
        except Exception as e:
            messagebox.showerror("ENSA - Grandes Clientes", f"Ocurrio un error {e}")

    def eliminar_cliente(self):
        nac = self.txt_nac.get()
        try:
            self.logica.eliminar_cliente(nac)
            self.destroy()
            messagebox.showinfo("ENSA - Grandes Clientes", "Cliente eliminado exitosamente")
        except Exception as e:
            messagebox.showerror("ENSA - Grandes Clientes", f"Ocurrio un error {e}")

    def limpiar_campos(self):
        self.txt_nickname_consumo.delete(0, tk.END)
        self.txt_nickname_demanda.delete(0, tk.END)
        self.txt_instalacion.delete(0, tk.END)
        self.txt_medidor.delete(0, tk.END)
        self.txt_cte.delete(0, tk.END)
        self.txt_nombre.delete(0, tk.END)
        self.cmb_tarifa.set('')
        self.dte_fecha_entrada.delete(0, tk.END)
        self.txt_precio_cpg.delete(0, tk.END)
    
