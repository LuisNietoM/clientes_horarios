import numpy as np
import tkinter as tk
from tkinter import ttk, messagebox
from logica_negocio.master_logica import MasterLogica
from datetime import datetime

class ConsultaDatosDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Formulario - Consultar Datos")
        self.logica = MasterLogica()
        self.df = None
        
        # Set the width based on the screen width
        self.screen_width = self.winfo_screenwidth()
        self.dialog_width = min(1200, self.screen_width - 40)  # Adjust as needed
        self.geometry(f"{self.dialog_width}x500")
        self.resizable(False, False)
        self.iconbitmap("./logo.ico")
        
        # Create a frame for the Treeview and scrollbars
        self.frame = ttk.Frame(self)
        self.frame.place(x=20, y=20, width=self.dialog_width - 40, height=400)
        self.frame.grid_rowconfigure(0, weight=1)
        self.frame.grid_columnconfigure(0, weight=1)
        self.frame.grid_columnconfigure(1, weight=0)
        
        # Create the Treeview with scrollbars
        self.tree = ttk.Treeview(self.frame, columns=[f"col{i+1}" for i in range(18)], show='headings')
        self.tree.grid(row=0, column=0, sticky='nsew')
        
        # Add horizontal scrollbar
        self.scroll_x = ttk.Scrollbar(self.frame, orient=tk.HORIZONTAL, command=self.tree.xview)
        self.scroll_x.grid(row=1, column=0, sticky='ew')
        self.tree.configure(xscrollcommand=self.scroll_x.set)
        
        # Add vertical scrollbar
        self.scroll_y = ttk.Scrollbar(self.frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.scroll_y.grid(row=0, column=1, sticky='ns')
        self.tree.configure(yscrollcommand=self.scroll_y.set)
        
        # Define column names and set column widths
        cols = [
            "NAC","Nickname Consumo","Nickname Demanda","Instalación",
            "Medidor","CTE","Nombre ","Tarifa","F. Entrada","Precio CPG",
            "KWh HP","KWh MFP","KWh BFP","KW HP","KW MFP","KW BFP","KVARH","PF",
        ]

        for i in range(18):
            col = f"col{i+1}"
            self.tree.heading(col, text=f"{cols[i]}")
            self.tree.column(col, width=100, anchor="center") 
        
        # Descargar button
        self.btn_consultar = ttk.Button(self, text="Consultar", command=self.consultar)
        self.btn_consultar.place(x=20, y=450, width=90, height=30)

        self.btn_consultar = ttk.Button(self, text="Descargar", command=self.descargar, style="success.TButton")
        self.btn_consultar.place(x=120, y=450, width=90, height=30)
    
    
    def consultar(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        
        try:
            self.df = self.logica.resultados()
            self.df['PF'] = np.round(np.cos(np.arctan(self.df['KVARH'] / self.df['KWh HP'])), 2)

            for dato in self.df.values:
                valores = [f"{valor: ,.2f}" if isinstance(valor, (int, float)) else str(valor) for valor in dato]
                self.tree.insert("", tk.END, values=valores)
        
        except Exception as e:
            messagebox.showerror("ENSA - Grandes Clientes", f"Ocurrio un error {e}")

    
    def descargar(self):
        try:
            fecha_hora = datetime.now().strftime("%Y%m%d_%H%M%S")
            nombre_archivo = f"resultados_{fecha_hora}.xlsx"
            self.df.to_excel(nombre_archivo, index=False)
            messagebox.showinfo("ENSA - Grandes Clientes", f"El archivo se ha descargado como {nombre_archivo}")
        except Exception as e:
            messagebox.showerror("ENSA - Grandes Clientes", f"Ocurrio un error {e}")
