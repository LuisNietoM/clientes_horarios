import numpy as np
import pandas as pd
from acceso_datos.feriado_datos import DiaFeriadoDatos
from acceso_datos.consumo_datos import ConsumosDatos

class ConsumoPorBloqueLogica:
    def __init__(self):
        dias_feriados = DiaFeriadoDatos().consultar()
        fechas = [fecha[0] for fecha in dias_feriados]
        self.dias_feriados = pd.to_datetime(fechas).tolist()

        self.datos = ConsumosDatos()
        self.df = None
    
    def calcular(self, archivo):
        df = pd.read_excel(archivo)
        clientes = df['GRAN CLIENTE'].unique()
        fechas = df['FECHA'].unique()

        cliente_ = []
        fecha_ = []
        horario_ = []
        bloque_ = []
        consumo_ = []

        for cliente in clientes:
            x = df[df['GRAN CLIENTE'] == cliente].copy()

            for fecha in fechas:
                y = x[x['FECHA'] == fecha].copy()
                fecha_dt = pd.to_datetime(fecha)
                
                if fecha_dt in self.dias_feriados or fecha_dt.day_name() == 'Sunday':
                    z = y.loc[(y['HORA'] <= 24), 'MEDICIONES'].copy()

                    cliente_.append(cliente)
                    fecha_.append(fecha)
                    horario_.append('De 00:00 a 24:00')
                    bloque_.append('Bajo')
                    consumo_.append(np.sum(z))

                elif fecha_dt.day_name() == 'Saturday':
                    z1 = y.loc[(y['HORA'] <= 11), 'MEDICIONES'].copy()
                    cliente_.append(cliente)
                    fecha_.append(fecha)
                    horario_.append('De 00:00 a 11:00')
                    bloque_.append('Bajo')
                    consumo_.append(np.sum(z1))

                    z2 = y.loc[(y['HORA'] >= 12) & (y['HORA'] <= 23), 'MEDICIONES'].copy()
                    cliente_.append(cliente)
                    fecha_.append(fecha)
                    horario_.append('De 11:00 a 23:00')
                    bloque_.append('Medio')
                    consumo_.append(np.sum(z2))

                    z3 = y.loc[(y['HORA'] > 23), 'MEDICIONES'].copy()
                    cliente_.append(cliente)
                    fecha_.append(fecha)
                    horario_.append('De 23:00 a 24:00')
                    bloque_.append('Bajo')
                    consumo_.append(np.sum(z3))

                else:
                    z1 = y.loc[(y['HORA'] <= 9), 'MEDICIONES'].copy()
                    cliente_.append(cliente)
                    fecha_.append(fecha)
                    horario_.append('De 00:00 a 09:00')
                    bloque_.append('Bajo')
                    consumo_.append(np.sum(z1))

                    z2 = y.loc[(y['HORA'] >= 10) & (y['HORA'] <= 17), 'MEDICIONES'].copy()
                    cliente_.append(cliente)
                    fecha_.append(fecha)
                    horario_.append('De 09:00 a 17:00')
                    bloque_.append('Punta')
                    consumo_.append(np.sum(z2))

                    z3 = y.loc[(y['HORA'] >= 18), 'MEDICIONES'].copy()
                    cliente_.append(cliente)
                    fecha_.append(fecha)
                    horario_.append('De 17:00 a 24:00')
                    bloque_.append('Medio')
                    consumo_.append(np.sum(z3))

        result = pd.DataFrame({
            'GRAN CLIENTE': cliente_,
            'FECHA': fecha_,
            'HORARIO': horario_,
            'CONSUMO': consumo_,
            'BLOQUE': bloque_
        })

        result['CONSUMO'] = result['CONSUMO'] * -1 
        result['CONSUMO'] = result['CONSUMO'] * 1_000
        
        self.df = result
        self.cargar_datos()
    
    def cargar_datos(self):
        self.datos.cargar_datos(self.df)

    def detalles(self):
        df = self.datos.detalles()
        return df