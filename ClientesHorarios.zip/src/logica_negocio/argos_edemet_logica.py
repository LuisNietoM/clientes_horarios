import pandas as pd
from acceso_datos.argos_edemet_datos import ArgosEdemetDatos

class ArgosEdemetLogica:
    def __init__(self):
        self.logica = ArgosEdemetDatos()

    def set_argos(self, archivo):
        cols = ["argos_a_e", "argostoc_a_e"]
        df = pd.read_excel(archivo, usecols=cols)
        df = df.sum()
        df = df.to_frame()
        df = df.reset_index()
        
        df = df.rename(columns={
            "index": "nickname_consumo", 
            0: "KWh HP"
        })
        
        self.logica.set_argos(df)

    def set_edemet(self, archivo):
        col = "ensa_a_cvi_115_11_s"
        df = pd.read_excel(archivo, usecols=[col])
        df["nickname_consumo"] = col
        
        df = df.groupby("nickname_consumo")\
            .sum()\
            .reset_index()
        df[col] = df[col] * -1
        
        df = df.rename(columns={col: "KWh HP"})
        
        self.logica.set_edemet(df)
