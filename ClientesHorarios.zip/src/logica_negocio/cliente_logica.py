from acceso_datos.cliente_datos import ClienteDatos

class ClienteLogica:
    def __init__(self):
        self.datos = ClienteDatos()

    def crear_cliente(
        self, 
        nac, 
        nickname_consumo,
        nickname_demanda, 
        instalacion, 
        medidor, 
        cte, 
        nombre, 
        tarifa, 
        fecha_entrada, 
        precio_cpg
    ):

        self.datos.crear_cliente(
            nac, 
            nickname_consumo,
            nickname_demanda, 
            instalacion, 
            medidor, 
            cte, 
            nombre, 
            tarifa, 
            fecha_entrada, 
            precio_cpg
        )
    
    
    def buscar_cliente(self, nac):
        return self.datos.buscar_cliente(nac)
    
    def editar_cliente(self, 
        nac, 
        nickname_consumo,
        nickname_demanda, 
        instalacion, 
        medidor, 
        cte, 
        nombre, 
        tarifa, 
        fecha_entrada, 
        precio_cpg
    ):

        self.datos.editar_cliente(
            nac, 
            nickname_consumo,
            nickname_demanda, 
            instalacion, 
            medidor, 
            cte, 
            nombre, 
            tarifa, 
            fecha_entrada, 
            precio_cpg
        )

    def eliminar_cliente(self, nac):
        self.datos.eliminar_cliente(nac)

    def listar(self):
        df = self.datos.listar()
        df.to_excel('plantilla_clientes.xlsx', index=False)
    
    def cargar_datos(self, df):
        self.datos.cargar_datos(df)