import pandas as pd
from acceso_datos.master_datos import MasterDatos
from acceso_datos.argos_edemet_datos import ArgosEdemetDatos

class MasterLogica:
    def __init__(self):
        self.datos = MasterDatos()
        self.argos_edemet = ArgosEdemetDatos()

    def resultados(self):
        clientes = self.datos.clientes()
        consumos = self.franjas_consumos()
        demanda = self.franjas_demanda_max()
        reactivo = self.datos.get_consumo_reactivo()

        # Procesamiento consumos
        consumos = consumos.reset_index()
        consumos = consumos.rename(columns={"GRAN CLIENTE": "nickname_consumo"})
        # Unir los consumos de edemet y argos
        edemet = self._consumo_edemet()
        consumos = pd.concat([consumos, edemet], axis=0, ignore_index=True)
        argos = self._consumo_argos()
        consumos = pd.concat([consumos, argos], axis=0, ignore_index=True)

        # Procesamiento consumos
        demanda = demanda.reset_index()
        demanda = demanda.rename(columns={"GRAN CLIENTE": "nickname_demanda"})

        # Procesamiento reactivo
        reactivo['medidor'] = reactivo['medidor'].apply(lambda x: str(x))

        # Joins
        df = pd.merge(clientes, consumos, how="left", on="nickname_consumo")
        df = pd.merge(df, demanda, how="left", on="nickname_demanda")
        df = pd.merge(df, reactivo, how="left", on="medidor")

        df = df.rename(columns={
            "nac": "NAC",
            "nickname_consumo": "NICKNAME CONSUMO",
            "nickname_demanda": "NICKNAME DEMANDA", 
            "instalacion": "INSTALACIÓN",
            "medidor": "MEDIDOR",
            "cte": "CTE", 
            "nombre": "NOMBRE",
            "tarifa": "TARIFA",
            "fecha_entrada": "F. ENTRADA", 
            "precio_cpg": "PRECIO CPG", 
        })

        return df

    def _consumo_edemet(self):
        df = self.argos_edemet.get_edemet()
        return df

    def _consumo_argos(self):
        df = self.argos_edemet.get_argos()
        return df
    
    def franjas_consumos(self):
        df = self.datos.consumos()
        pivot = df.pivot_table(
            values="CONSUMO", 
            index="GRAN CLIENTE", 
            columns="BLOQUE",
            aggfunc="sum"
        )

        pivot = pivot.rename(columns={
            "Punta": "KWh HP",
            "Medio" :"KWh MFP", 
            "Bajo" :"KWh BFP"
        })
        
        return pivot[["KWh HP","KWh MFP", "KWh BFP"]]
    
    def franjas_demanda_max(self):
        df = self.datos.demandas_max()

        pivot = df.pivot_table(
            values="DEMANDA MÁX", 
            index="GRAN CLIENTE", 
            columns="BLOQUE",
            aggfunc="max"
        )
        
        pivot = pivot.rename(columns={
            "Punta": "KW HP",
            "Medio" :"KW MFP", 
            "Bajo" :"KW BFP"
        })
        
        return pivot[["KW HP","KW MFP", "KW BFP"]]
    
    def consumo_reactivo(self, archivo):
        df = pd.read_excel(archivo, usecols=["SERIALNO", "Consumo Reactivo Acum"])
        df = df.rename(columns={"SERIALNO": "medidor", "Consumo Reactivo Acum": "KVARH"})
        self.datos.set_consumo_reactivo(df)
