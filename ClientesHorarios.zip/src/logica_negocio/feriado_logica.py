from acceso_datos.feriado_datos import DiaFeriadoDatos

class DiaFeriadoLogica:
    def __init__(self):
        self.datos = DiaFeriadoDatos()

    def agregar(self, fecha, descripcion):
        self.datos.agregar(fecha, descripcion)
    
    def consultar(self):
        return self.datos.consultar()
    
    def eliminar(self, fecha):
        self.datos.eliminar(fecha)



 
