if __name__ == "__main__":
    from gui.app import App
    app = App()
    app.mainloop()
