import pandas as pd
from acceso_datos.conexion_datos import ConexionBaseDatos

class ConsumosDatos:
    def __init__(self):
        self.db = ConexionBaseDatos()

    def cargar_datos(self, df):
        df.to_sql('consumos', self.db.conn, if_exists='replace', index=False)

    def detalles(self):
        df = pd.read_sql("SELECT * FROM consumos;", self.db.conn)
        return df