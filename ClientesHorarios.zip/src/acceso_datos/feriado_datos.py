from acceso_datos.conexion_datos import ConexionBaseDatos

class DiaFeriadoDatos:
    def __init__(self):
        self.db = ConexionBaseDatos()
        self.crear_tabla()

    def crear_tabla(self):
        query = """
        CREATE TABLE IF NOT EXISTS dias_feriados (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT NOT NULL UNIQUE,
            descripcion NOT NULL
        );
        """
        self.db.conn.execute(query)
        self.db.conn.commit()
    
    def agregar(self, fecha, descripcion):
        query = """
        INSERT INTO dias_feriados (fecha, descripcion)
        VALUES (?, ?);
        """
        cursor = self.db.conn.cursor()
        cursor.execute(query, (fecha, descripcion,))
        self.db.conn.commit()

    def consultar(self):
        query = """
        SELECT fecha, descripcion FROM dias_feriados ORDER BY fecha;
        """
        res = self.db.conn.execute(query)
        return res.fetchall()
    
    def eliminar(self, fecha):
        query = """
        DELETE FROM dias_feriados WHERE fecha = ?;
        """
        self.db.conn.execute(query, (fecha,))
        self.db.conn.commit()

