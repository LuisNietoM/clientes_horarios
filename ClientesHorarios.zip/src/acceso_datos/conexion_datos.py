import sqlite3

class ConexionBaseDatos:
    def __init__(self, nombre_bd="./db.sqlite3"):
        self.nombre_bd = nombre_bd
        self.conn = sqlite3.connect(self.nombre_bd, check_same_thread=False)