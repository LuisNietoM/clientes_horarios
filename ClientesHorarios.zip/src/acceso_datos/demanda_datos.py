import pandas as pd 
from acceso_datos.conexion_datos import ConexionBaseDatos

class DemandaMaxDatos:
    def __init__(self):
        self.db = ConexionBaseDatos()

    def cargar_datos(self, df):
        df.to_sql('demandas_max', self.db.conn, if_exists='replace', index=False)

    def detalles(self):
        df = pd.read_sql("SELECT * FROM demandas_max;", self.db.conn)
        return df
