import pandas as pd
from acceso_datos.conexion_datos import ConexionBaseDatos

class ClienteDatos:
    def __init__(self):
        self.db = ConexionBaseDatos()
        self.crear_tabla_clientes()

    def crear_tabla_clientes(self):
        query = """
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nac TEXT NOT NULL UNIQUE,
            nickname_consumo TEXT,
            nickname_demanda TEXT,
            instalacion TEXT,
            medidor TEXT,
            cte TEXT,
            nombre TEXT NOT NULL,
            tarifa TEXT,
            fecha_entrada TEXT,
            precio_cpg REAL
        );
        """
        self.db.conn.execute(query)
        self.db.conn.commit()

    def crear_cliente(
        self,
        nac,
        nickname_consumo,
        nickname_demanda,
        instalacion,
        medidor,
        cte,
        nombre,
        tarifa,
        fecha_entrada,
        precio_cpg
    ):
        query = """
        INSERT INTO clientes (
            nac,
            nickname_consumo,
            nickname_demanda,
            instalacion,
            medidor,
            cte,
            nombre,
            tarifa,
            fecha_entrada,
            precio_cpg
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """
        
        self.db.conn.execute(query, (
            nac,
            nickname_consumo,
            nickname_demanda,
            instalacion,
            medidor,
            cte,
            nombre,
            tarifa,
            fecha_entrada,
            precio_cpg
        ))

        self.db.conn.commit()

    def buscar_cliente(self, nac):
        query = """
        SELECT * FROM clientes WHERE nac = ?;
        """
        res = self.db.conn.execute(query, (nac,))
        return res.fetchall()
    
    def editar_cliente(
        self,
        nac,
        nickname_consumo,
        nickname_demanda,
        instalacion,
        medidor,
        cte,
        nombre,
        tarifa,
        fecha_entrada,
        precio_cpg
    ):
        query = """
        UPDATE clientes 
        SET 
            nickname_consumo = ?,
            nickname_demanda = ?,
            instalacion = ?,
            medidor = ?,
            cte = ?,
            nombre = ?,
            tarifa = ?,
            fecha_entrada = ?,
            precio_cpg = ?
        WHERE nac = ?
        """
        self.db.conn.execute(query, (
            nickname_consumo,
            nickname_demanda,
            instalacion,
            medidor,
            cte,
            nombre,
            tarifa,
            fecha_entrada,
            precio_cpg,
            nac
        ))

        self.db.conn.commit()

    def eliminar_cliente(self, nac):
        query = """
        DELETE FROM clientes WHERE nac = ?;
        """
        self.db.conn.execute(query, (nac,))
        self.db.conn.commit()

    def listar(self):
        query = """
        SELECT * FROM clientes;
        """
        df = pd.read_sql_query(query, self.db.conn, index_col='id')
        return df
    
    def cargar_datos(self, df):
        query = """
        DELETE FROM clientes;
        """

        self.db.conn.execute(query)
        self.db.conn.commit()
        
        df.to_sql('clientes', self.db.conn, if_exists='append', index=False)

