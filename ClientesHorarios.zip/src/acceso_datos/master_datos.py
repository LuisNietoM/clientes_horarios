import pandas as pd
from acceso_datos.conexion_datos import ConexionBaseDatos

class MasterDatos:
    def __init__(self):
        self.db = ConexionBaseDatos()

    # La demanda reactiva la envio acá porque solo es cargar y descargar una columna
    def set_consumo_reactivo(self, df):
        df.to_sql('consumo_reactivo', self.db.conn, if_exists='replace', index=False)
    
    def get_consumo_reactivo(self):
        df = pd.read_sql_query("SELECT * FROM consumo_reactivo;", self.db.conn)
        return df

    def clientes(self):
        df = pd.read_sql_query("SELECT * FROM clientes;", self.db.conn, index_col="id")
        return df

    def demandas_max(self):
        df = pd.read_sql_query("SELECT * FROM demandas_max;", self.db.conn)
        return df
    
    def consumos(self):
        df = pd.read_sql_query("SELECT * FROM consumos;", self.db.conn)
        return df
    
