import pandas as pd
from acceso_datos.conexion_datos import ConexionBaseDatos

class ArgosEdemetDatos:
    def __init__(self):
        self.db = ConexionBaseDatos()

    def set_argos(self, df):
        df.to_sql("argos", self.db.conn, if_exists='replace', index=False)

    def set_edemet(self, df):
        df.to_sql("edemet", self.db.conn, if_exists='replace', index=False)

    def get_argos(self):
        df = pd.read_sql('SELECT * FROM argos;', self.db.conn)
        return df

    def get_edemet(self):
        df = pd.read_sql('SELECT * FROM edemet;', self.db.conn)
        return df

